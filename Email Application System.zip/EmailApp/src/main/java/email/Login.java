package email;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Login {
	private static Statement st;
	private static ResultSet rs;
	private static Connection conn;

	public static void login() throws SQLException {
		Scanner sc=new Scanner(System.in);
	
		try {
			conn=DatabaseConnection.connection();
			st=conn.createStatement();
		
		
		 System.out.println("Mailid: ");
			String mailid1=sc.next();
			System.out.println("Enter the password:");
			String password1=sc.next();
			String s1="select * from  email where mailid='"+mailid1+"' and password='"+password1+"'";
			//select *from email where mailid="g@gmail.com"and password="gopika123";
			rs=st.executeQuery(s1);
			if(rs.next()) {
				System.out.println("Logged in!!");
			} 
			else {
				System.out.println("Invalid mailid / Password");
			}
			
	
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		 }
		 
	}
	

