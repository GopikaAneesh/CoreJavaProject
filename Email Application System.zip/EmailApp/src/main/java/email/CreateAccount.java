package email;


import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CreateAccount {
	private static Statement st;
	private static ResultSet rs;
	private static Connection conn;
	//isValid() for mobile number validation
		public static boolean isValid(String mobno) {
			//checking whether mobno contains 10 char or not
			Pattern p = Pattern.compile("^\\d{10}$");
			//check whether mobno matches the pattern
			Matcher m1 = p.matcher(mobno);
			return (m1.matches());
		}
		//randomPassword() for generating random password
	public static char randomPassword() {
			//using Math.random()
			int randPass= (int) (Math.random()*62);

			//if conditions for digits&upper&lowercase letters
			//0-9 digits
			  if (randPass<=9) {
				  
				  int ascii=randPass +48;//48-0=48
				  return (char)(ascii);
				  
			  }
			  //26 lowercase
			  else if(randPass<=35) {
				  int ascii1=randPass +55;//65-10=55
				  return (char)(ascii1);
				  
			  }
			  //26 uppercase
			  else {
				  int ascii2=randPass +61;//97-36=61
				  return (char)(ascii2);
				  
			  }
		}
	//strength() for finding the strength of password
		public static String strength(int lengthPass) {
			if(lengthPass<10)
			{
				return "Weak Password";
			}
			else if(lengthPass>10 && lengthPass<=12 )
			{
				return "Medium Password";
			}
			else {
				return "Suggesting Strong Password";
			}
		}
	//printPassword() for printing the random password
		public static void printPassword(String[] arr) {
			for(int i=0;i<arr.length;i++) {
				System.out.println(arr[i]);
			
		}
		}
	
	public static void create() throws SQLException {
		
		Scanner sc=new Scanner(System.in);
		try {
			conn=DatabaseConnection.connection();
			st=conn.createStatement();
		
		 int i = 0;
			
			String mailid = null;
			int noOfRanPass=1;
			  int lengthPass=15;
			  String mobno = null;
			  String alternateid = null;
			 
			while(i==0) 
			{
				
			System.out.println("Enter your email id: ");
			 mailid=sc.next();//@***.com
			if((mailid.contains("@gmail.com"))||(mailid.contains("@yahoo.com"))||(mailid.contains("@live.com"))
					||(mailid.contains("@outlook.com"))||(mailid.contains("@icloud.com"))||(mailid.contains("@hotmail.com"))) {
				
				i=i+1;
			}//if
			
			else {
				System.out.println("Ivalid mailid");
				
			}//else
			}//while
			
		
		 String sel="select * from  email where mailid='"+mailid+"'";
			//to check whether eid exits
			rs=st.executeQuery(sel);//select
			if(rs.next()) {
				
				System.out.println("Email id already exists");
			} //if it is there not go to insert
			else {
			
				 System.out.println("Enter the firstname: ");
					String firstname=sc.next();
					System.out.println("Enter the last name:");
					String lastname=sc.next();
					String username=firstname+" "+lastname;
					 
				 String[] randompasswords=new String[noOfRanPass];
				 
				  for(int b=0;b<noOfRanPass;b++) {
					  String randomPassword="";
					  for(int e=0;e<lengthPass;e++) {
						  randomPassword += randomPassword();
					  }
					  randompasswords[b]=randomPassword;
				  }
				  System.out.println(strength(lengthPass));
				 	printPassword(randompasswords);
				
				System.out.println("Enter your own password: ");
				String password=sc.next();
				int j = 0;
				while(j==0) {
				System.out.println("Reenter the password ");
				String repass=sc.next();
				if(repass.equals(password)) {
					System.out.println("Password is verified");
					j=j+1;
				}//2if
				else {
					System.out.println("Password mismatch");
				}//2else
				}//2while
			 
				int m=0;
				
				while(m==0) {
				System.out.println("Enter the alternate email: ");
			    alternateid=sc.next();
				
				if(mailid.equals(alternateid)) {
					System.out.println("Invalid Email!!!");
				}//3if
				else {
					if((alternateid.contains("@gmail.com"))||(alternateid.contains("@yahoo.com"))
							||(alternateid.contains("@live.com"))||(alternateid.contains("@outlook.com"))
							||(alternateid.contains("@icloud.com"))||(alternateid.contains("@hotmail.com"))) 
					{
						System.out.println("Alternate id assigned");
						m=m+1;
					}//4if
					else {
						System.out.println("Ivalid Email");
						
					}//4else
					
				}//3else
				}//3while
				int k=0;
				while(k==0) {
				System.out.println("Enter the mobile number:");
				mobno=sc.next();
				
				if(isValid(mobno)) {
					k=k+1;
				}
				else {
					System.out.println("Invalid mobile number");
					
				}
				}
				int min = 1000;
			    int max = 9999;
			   
			  int c=0;
			    while(c==0) {
			    	int r=(int)(Math.random()*(max-min+1)+min);
			    System.out.print("Your otp is : ");
			    System.out.println(r);
			    System.out.println("Enter OTP");
			    int o=sc.nextInt();
			    if(o==r) {
			    	
			    	c=c+1;
			    }//5if
			    else {
			    	System.out.println("Invalid OTP");
			    	System.out.println("Resend OTP (yes/no):");
			    	String ch=sc.next();
			    	if(ch.equals("no")) {
			    		System.out.println("Account not created");
			    		
			    	}//if
			    
			       if(ch.equals("yes")) {
			    	   c=0;
			    	}//if
			    }//4while
			    }//5else
			    
			   
				
				String ins="insert into email values('"+mailid+"','"+username+"','"+password+"','"+alternateid+"','"+mobno+"')";
				int i1=st.executeUpdate(ins);//insert, update and delete 
				if(i1>0) {
					System.out.println("Account created");
				}
				else {
					System.out.println("Record not inserted");
				}
			
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
}

