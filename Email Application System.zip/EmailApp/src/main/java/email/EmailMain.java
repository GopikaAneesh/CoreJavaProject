package email;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class EmailMain {
	
	public static void main(String[] args) throws SQLException {
		
			 String yes="0";
			 while(yes.equals("0")) {
				 Scanner sc=new Scanner(System.in);
			 System.out.println("Enter your choice: ");
			 System.out.println("1.Create an account\n2.Login");
			 
			 int choice=sc.nextInt();
			
			 switch(choice) {
			 
			 case 1:{
				CreateAccount.create();
				break;
				 
			 }
			 case 2:
			 {
				 Login.login();
				 break;
				 }
			 default:
				 System.out.println("Invalid Input");
			 } 
			 System.out.println("Do you want to continue(yes/no)");
				 String yn=sc.next();
				 if(yn.equals("yes")) {
					 yes="0";
				 }
				 else {
					 break;
				 }
               
				}
		
			 }
		}
